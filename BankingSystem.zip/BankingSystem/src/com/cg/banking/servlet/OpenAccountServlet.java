package com.cg.banking.servlet;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/openAccountServlet")
public class OpenAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			BankingServices bankingServices=new BankingServicesImpl();
		String accountType=request.getParameter("accountType");
		float accountBalance=Float.parseFloat(request.getParameter("accountBalance"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		long accountNumber=0;
		Account account=null;
		try {
			accountNumber=bankingServices.openAccount(accountType, accountBalance,pinNumber);
			account=bankingServices.getAccountDetails(accountNumber);
			HttpSession session=request.getSession();
			session.setAttribute("account",account );
		} catch (InvalidAmountException | InvalidAccountTypeException
				| BankingServicesDownException | AccountNotFoundException e) {
			request.setAttribute("account", e.getMessage());
		}
		finally{
			//request.setAttribute("account",account );
			RequestDispatcher dispatcher= request.getRequestDispatcher("insideLoginPage.jsp");
			dispatcher.forward(request, response);
		}
	}
}
